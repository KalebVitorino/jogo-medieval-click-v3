const navItems = document.querySelectorAll(".nav-item");
const screens = document.querySelectorAll(".screen");

const throneScreen = document.querySelector(".throne");
const kingdomScreen = document.querySelector(".kingdom");
const worldScreen = document.querySelector(".world");
const troopsScreen = document.querySelector(".troops");
const throneLevelBtn = document.getElementById("throneLevelBtn");
const castleUpgradeBtn = document.getElementById("castleUpgradeBtn");
const castleUpgradeTitle = document.getElementById("castleUpgradeTitle");
const castleRequirements = document.getElementById("castleRequirements");
const castleKingdomRequirement = document.getElementById("castleKingdomRequirement");
const castleGoldRequirement = document.getElementById("castleGoldRequirement");
const castleLevelLabel = document.getElementById("castleLevelLabel");
const worldMapBtn = document.getElementById("worldMapBtn");
const troopsLevelBtn = document.getElementById("troopsLevelBtn");
const barracksUpgradeTitle = document.getElementById("barracksUpgradeTitle");
const barracksLevelLabel = document.getElementById("barracksLevelLabel");
const barracksRequirements = document.getElementById("barracksRequirements");
const barracksCastleRequirement = document.getElementById("barracksCastleRequirement");
const barracksGoldRequirement = document.getElementById("barracksGoldRequirement");
const testSoldiersBtn = document.getElementById("testSoldiersBtn");
const attackButtonsLayer = document.getElementById("attackButtonsLayer");
const warMenu = document.getElementById("warMenu");
const warCloseBtn = document.getElementById("warCloseBtn");
const warTitle = document.getElementById("warTitle");
const warProgressDots = document.getElementById("warProgressDots");
const enemyForceValue = document.getElementById("enemyForceValue");
const warFoodCostValue = document.getElementById("warFoodCostValue");
const warAttackBtn = document.getElementById("warAttackBtn");
const warFeedback = document.getElementById("warFeedback");
const totalSoldiersValue = document.getElementById("totalSoldiersValue");
const totalForceValue = document.getElementById("totalForceValue");
const buySwordsmanBtn = document.getElementById("buySwordsmanBtn");
const buyArcherBtn = document.getElementById("buyArcherBtn");
const buyKnightBtn = document.getElementById("buyKnightBtn");
const swordsmanCount = document.getElementById("swordsmanCount");
const archerCount = document.getElementById("archerCount");
const knightCount = document.getElementById("knightCount");
const eventTestBtn = document.getElementById("eventTestBtn");
const resetGameBtn = document.getElementById("resetGameBtn");
const throneEventPanel = document.getElementById("throneEventPanel");
const eventCloseBtn = document.getElementById("eventCloseBtn");
const eventCategory = document.getElementById("eventCategory");
const eventTitle = document.getElementById("eventTitle");
const eventDescription = document.getElementById("eventDescription");
const eventOptions = document.getElementById("eventOptions");
const eventFeedback = document.getElementById("eventFeedback");
const throneEventBadge = document.getElementById("throneEventBadge");
const throneNavItem = document.getElementById("throneNavItem");
const missionHudBtn = document.getElementById("missionHudBtn");
const missionHudProgress = document.getElementById("missionHudProgress");
const missionReadyBadge = document.getElementById("missionReadyBadge");
const missionPanel = document.getElementById("missionPanel");
const missionCloseBtn = document.getElementById("missionCloseBtn");
const missionTitle = document.getElementById("missionTitle");
const missionDescription = document.getElementById("missionDescription");
const missionProgressFill = document.getElementById("missionProgressFill");
const missionProgressText = document.getElementById("missionProgressText");
const missionRewardText = document.getElementById("missionRewardText");
const missionCollectBtn = document.getElementById("missionCollectBtn");
const missionFeedback = document.getElementById("missionFeedback");

const goldValue = document.getElementById("goldValue");
const foodValue = document.getElementById("foodValue");
const gemValue = document.getElementById("gemValue");
const goldPerSecondTop = document.getElementById("goldPerSecondTop");
const foodPerSecondTop = document.getElementById("foodPerSecondTop");
const collectGoldBtn = document.getElementById("collectGoldBtn");
const testGoldBtn = document.getElementById("testGoldBtn");
const testFoodBtn = document.getElementById("testFoodBtn");
const collectFoodBtn = document.getElementById("collectFoodBtn");
const goldClickHint = document.getElementById("goldClickHint");
const foodClickHint = document.getElementById("foodClickHint");

const houseClickUpgradeBtn = document.getElementById("houseClickUpgradeBtn");
const houseSecondUpgradeBtn = document.getElementById("houseSecondUpgradeBtn");
const farmClickUpgradeBtn = document.getElementById("farmClickUpgradeBtn");
const farmSecondUpgradeBtn = document.getElementById("farmSecondUpgradeBtn");

const goldPerClickLabel = document.getElementById("goldPerClickLabel");
const goldPerSecondLabel = document.getElementById("goldPerSecondLabel");
const foodPerClickLabel = document.getElementById("foodPerClickLabel");
const foodPerSecondLabel = document.getElementById("foodPerSecondLabel");
const houseClickPriceLabel = document.getElementById("houseClickPriceLabel");
const houseSecondPriceLabel = document.getElementById("houseSecondPriceLabel");
const farmClickPriceLabel = document.getElementById("farmClickPriceLabel");
const farmSecondPriceLabel = document.getElementById("farmSecondPriceLabel");
const houseClickLevelLabel = document.getElementById("houseClickLevelLabel");
const houseSecondLevelLabel = document.getElementById("houseSecondLevelLabel");
const farmClickLevelLabel = document.getElementById("farmClickLevelLabel");
const farmSecondLevelLabel = document.getElementById("farmSecondLevelLabel");

const maxThroneLevel = 10;
const maxKingdomLevel = 10;
const maxWorldMap = 3;
const maxTroopsLevel = 10;
let throneLevel = 1;
let kingdomLevel = 1;
let worldMap = 1;
let troopsLevel = 1;
let selectedEnemy = null;

const victoryCasualtyRate = 0.20;
const defeatCasualtyRate = 0.40;
const battleForceMultiplier = 1.12;
const battleFoodMultiplier = 1.15;

const resources = { gold: 0, food: 0, gems: 0 };
const production = { goldPerClick: 1, goldPerSecond: 0, foodPerClick: 1, foodPerSecond: 0 };
const upgradePrices = {
  houseClick: 40,
  houseSecond: 60,
  farmClick: 40,
  farmSecond: 60,
};
const upgradeLevels = {
  houseClick: 0,
  houseSecond: 0,
  farmClick: 0,
  farmSecond: 0,
};
const upgradesPerCastleLevel = 10;
const upgradePriceMultiplier = 1.25;

const castleUpgradeRequirements = {
  2: { kingdoms: 2, gold: 12000 },
  3: { kingdoms: 4, gold: 28000 },
  4: { kingdoms: 6, gold: 50000 },
  5: { kingdoms: 8, gold: 80000 },
  6: { kingdoms: 10, gold: 120000 },
  7: { kingdoms: 12, gold: 170000 },
  8: { kingdoms: 15, gold: 230000 },
  9: { kingdoms: 18, gold: 300000 },
  10: { kingdoms: 22, gold: 400000 },
};

const barracksUpgradeRequirements = {
  2: { gold: 3000 },
  3: { gold: 7000 },
  4: { gold: 12500 },
  5: { gold: 20000 },
  6: { gold: 30000 },
  7: { gold: 42500 },
  8: { gold: 57500 },
  9: { gold: 75000 },
  10: { gold: 100000 },
};
const troopTypes = {
  swordsman: { name: "Espadachim", cost: 3, force: 1, unlockLevel: 1, count: 0 },
  archer: { name: "Arqueiro", cost: 7, force: 2, unlockLevel: 2, count: 0 },
  knight: { name: "Cavaleiro", cost: 14, force: 4, unlockLevel: 3, count: 0 },
};

const throneEvents = [
  { id: "merchants", category: "🪙 Economia", title: "Mercadores chegaram", description: "Uma caravana pede autorização para negociar dentro do reino.", options: [
      { label: "Cobrar taxa", detail: "+70 ouro", reward: { gold: 70 } },
      { label: "Comprar alimentos", detail: "-60 ouro • +100 comida", cost: { gold: 60 }, reward: { food: 100 } },
    ] },
  { id: "harvest", category: "🌾 Produção", title: "Boa colheita", description: "Os campos produziram mais do que o esperado nesta estação.", options: [
      { label: "Guardar alimentos", detail: "+120 comida", reward: { food: 120 } },
      { label: "Vender excedente", detail: "+80 ouro", reward: { gold: 80 } },
    ] },
  { id: "mercenaries", category: "⚔️ Militar", title: "Mercenários disponíveis", description: "Um pequeno grupo de combatentes oferece seus serviços ao reino.", options: [
      { label: "Contratar", detail: "-45 comida • +10 espadachins", cost: { food: 45 }, reward: { swordsmen: 10 } },
      { label: "Dispensar", detail: "Sem custo", reward: {} },
    ] },
  { id: "peasants", category: "👑 Reino", title: "Camponeses pedem ajuda", description: "Uma aldeia perdeu parte de seus suprimentos e pede apoio da coroa.", options: [
      { label: "Enviar ajuda", detail: "-60 ouro • +80 comida", cost: { gold: 60 }, reward: { food: 80 } },
      { label: "Não intervir", detail: "Sem efeito", reward: {} },
    ] },
  { id: "robbed-caravan", category: "⚔️ Militar", title: "Caravana saqueada", description: "Bandidos atacaram comerciantes próximos às fronteiras do reino.", options: [
      { label: "Enviar patrulha", detail: "Requer 20 soldados • +90 ouro", requires: { soldiers: 20 }, reward: { gold: 90 } },
      { label: "Ignorar", detail: "Sem efeito", reward: {} },
    ] },
];

let activeThroneEvent = null;
let lastThroneEventId = null;
let eventResolutionTimer = null;
let eventChoiceLocked = false;
let pendingThroneEvent = null;
let throneEventTimer = null;
let nextThroneEventAt = null;
const throneEventMinDelay = 90 * 1000;
const throneEventMaxDelay = 3 * 60 * 1000;

const SAVE_KEY = "jogo-v3-save-v1";
let saveReady = false;
let saveDebounceTimer = null;
let restoredCurrentScreen = "trono";
let restoredOpenEventId = null;
let restoredMissionPanelOpen = false;

const missionStats = {
  goldProduced: 0,
  foodProduced: 0,
  soldiersRecruited: 0,
  upgradesBought: 0,
  battlesWon: 0,
  forceAdded: 0,
  goldClicks: 0,
  foodClicks: 0,
};

const missionTemplates = [
  { id: "produce-gold", metric: "goldProduced", target: 120, title: "Encha os cofres", description: "Produza 120 de ouro pelas casas ou coleta do Trono.", reward: { food: 50 } },
  { id: "produce-food", metric: "foodProduced", target: 180, title: "Abasteça o reino", description: "Produza 180 de comida pelas fazendas ou coleta do Trono.", reward: { gold: 45 } },
  { id: "recruit-soldiers", metric: "soldiersRecruited", target: 10, title: "Reforce as fileiras", description: "Recrute 10 soldados no Quartel.", reward: { gold: 55 } },
  { id: "buy-upgrades", metric: "upgradesBought", target: 2, title: "Invista no reino", description: "Compre 2 melhorias de casas ou fazendas.", reward: { food: 60 } },
  { id: "win-battle", metric: "battlesWon", target: 1, title: "Vitória no campo", description: "Vença 1 batalha no mapa.", reward: { gold: 80 } },
  { id: "increase-force", metric: "forceAdded", target: 20, title: "Fortaleça o exército", description: "Adicione 20 pontos de força ao seu exército.", reward: { food: 70 } },
  { id: "gold-clicks", metric: "goldClicks", target: 20, title: "Trabalho dos cobradores", description: "Colete ouro manualmente 20 vezes no Trono.", reward: { food: 40 } },
  { id: "food-clicks", metric: "foodClicks", target: 20, title: "Estoque real", description: "Colete comida manualmente 20 vezes no Trono.", reward: { gold: 40 } },
];

let activeMission = null;
let lastMissionId = null;
let missionFeedbackTimer = null;

// Cada castelo é uma pequena campanha. A força sobe 12% e o custo 15%
// de uma batalha para a seguinte. O progresso só avança em caso de vitória.
const worldAttackPoints = {
  1: [
    { id: "green-deer", x: 184, y: 520, label: "Reino verde", baseForce: 120, baseFoodCost: 500, battleCount: 3, currentBattle: 0, conquered: false },
    { id: "purple-eye", x: 554, y: 405, label: "Reino roxo", baseForce: 150, baseFoodCost: 625, battleCount: 3, currentBattle: 0, conquered: false },
    { id: "black-bull", x: 733, y: 805, label: "Reino negro", baseForce: 185, baseFoodCost: 781, battleCount: 4, currentBattle: 0, conquered: false },
    { id: "blue-trident", x: 220, y: 976, label: "Reino azul", baseForce: 225, baseFoodCost: 976, battleCount: 4, currentBattle: 0, conquered: false },
    { id: "red-wolf", x: 724, y: 1262, label: "Reino vermelho", baseForce: 275, baseFoodCost: 1220, battleCount: 5, currentBattle: 0, conquered: false },
  ],
  2: [
    { id: "purple-sigil", x: 171, y: 590, label: "Reino roxo", baseForce: 335, baseFoodCost: 1525, battleCount: 3, currentBattle: 0, conquered: false },
    { id: "green-tree", x: 704, y: 466, label: "Reino verde", baseForce: 405, baseFoodCost: 1906, battleCount: 4, currentBattle: 0, conquered: false },
    { id: "blue-deer", x: 706, y: 985, label: "Reino azul", baseForce: 490, baseFoodCost: 2383, battleCount: 4, currentBattle: 0, conquered: false },
    { id: "red-trident", x: 188, y: 1146, label: "Reino vermelho", baseForce: 590, baseFoodCost: 2979, battleCount: 5, currentBattle: 0, conquered: false },
  ],
  3: [
    { id: "black-axes", x: 363, y: 350, label: "Reino negro", baseForce: 710, baseFoodCost: 3724, battleCount: 4, currentBattle: 0, conquered: false },
    { id: "green-serpent", x: 714, y: 480, label: "Reino verde", baseForce: 850, baseFoodCost: 4655, battleCount: 4, currentBattle: 0, conquered: false },
    { id: "blue-trident", x: 160, y: 660, label: "Reino azul", baseForce: 1020, baseFoodCost: 5819, battleCount: 5, currentBattle: 0, conquered: false },
    { id: "purple-deer", x: 706, y: 845, label: "Reino roxo", baseForce: 1225, baseFoodCost: 7274, battleCount: 5, currentBattle: 0, conquered: false },
    { id: "red-sigil", x: 612, y: 1242, label: "Reino vermelho", baseForce: 1470, baseFoodCost: 9093, battleCount: 5, currentBattle: 0, conquered: false },
  ],
};

function getSerializableWorldProgress(){
  const progress = {};
  Object.entries(worldAttackPoints).forEach(([mapNumber, enemies]) => {
    progress[mapNumber] = enemies.map(enemy => ({
      id: enemy.id,
      currentBattle: enemy.currentBattle,
      conquered: enemy.conquered,
    }));
  });
  return progress;
}

function getGameSaveData(){
  const safeActiveEventId = eventChoiceLocked ? null : activeThroneEvent?.id || null;
  const safePendingEventId = eventChoiceLocked ? null : pendingThroneEvent?.id || null;

  return {
    version: 1,
    savedAt: Date.now(),
    currentScreen: getCurrentScreenName(),
    levels: {
      throne: throneLevel,
      kingdom: kingdomLevel,
      worldMap,
      troops: troopsLevel,
    },
    resources: { ...resources },
    production: { ...production },
    upgradePrices: { ...upgradePrices },
    upgradeLevels: { ...upgradeLevels },
    troops: Object.fromEntries(
      Object.entries(troopTypes).map(([key, troop]) => [key, troop.count])
    ),
    worldProgress: getSerializableWorldProgress(),
    missionStats: { ...missionStats },
    activeMission: activeMission ? { ...activeMission } : null,
    lastMissionId,
    events: {
      pendingEventId: safePendingEventId,
      activeEventId: safeActiveEventId,
      lastEventId: lastThroneEventId,
      nextEventAt: nextThroneEventAt,
    },
    ui: {
      missionPanelOpen: missionPanel?.classList.contains("open") || false,
    },
  };
}

function saveGameState(){
  if (!saveReady) return;
  try {
    localStorage.setItem(SAVE_KEY, JSON.stringify(getGameSaveData()));
  } catch (error) {
    console.warn("Não foi possível salvar o progresso do Jogo V3.", error);
  }
}

function scheduleSave(){
  if (!saveReady) return;
  if (saveDebounceTimer) clearTimeout(saveDebounceTimer);
  saveDebounceTimer = setTimeout(() => {
    saveDebounceTimer = null;
    saveGameState();
  }, 250);
}

function resetGameProgress(){
  const confirmed = window.confirm("Resetar todo o progresso do jogo? Esta ação apagará o save deste navegador e não poderá ser desfeita.");
  if (!confirmed) return;

  saveReady = false;
  if (saveDebounceTimer) {
    clearTimeout(saveDebounceTimer);
    saveDebounceTimer = null;
  }
  try {
    localStorage.removeItem(SAVE_KEY);
  } catch (error) {
    console.warn("Não foi possível apagar o save do Jogo V3.", error);
  }
  window.location.reload();
}

function loadGameState(){
  let saved;
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return false;
    saved = JSON.parse(raw);
  } catch (error) {
    console.warn("Não foi possível carregar o progresso do Jogo V3.", error);
    return false;
  }

  if (!saved || saved.version !== 1) return false;

  const clampInt = (value, min, max, fallback) => {
    const number = Number(value);
    if (!Number.isFinite(number)) return fallback;
    return Math.max(min, Math.min(max, Math.round(number)));
  };
  const safeNumber = (value, fallback = 0) => {
    const number = Number(value);
    return Number.isFinite(number) ? Math.max(0, number) : fallback;
  };

  if (saved.levels) {
    throneLevel = clampInt(saved.levels.throne, 1, maxThroneLevel, throneLevel);
    kingdomLevel = clampInt(saved.levels.kingdom, 1, maxKingdomLevel, kingdomLevel);
    worldMap = clampInt(saved.levels.worldMap, 1, maxWorldMap, worldMap);
    troopsLevel = Math.min(clampInt(saved.levels.troops, 1, maxTroopsLevel, troopsLevel), kingdomLevel);
  }

  if (saved.resources) {
    resources.gold = safeNumber(saved.resources.gold, resources.gold);
    resources.food = safeNumber(saved.resources.food, resources.food);
    resources.gems = safeNumber(saved.resources.gems, resources.gems);
  }

  if (saved.production) {
    production.goldPerClick = safeNumber(saved.production.goldPerClick, production.goldPerClick);
    production.goldPerSecond = safeNumber(saved.production.goldPerSecond, production.goldPerSecond);
    production.foodPerClick = safeNumber(saved.production.foodPerClick, production.foodPerClick);
    production.foodPerSecond = safeNumber(saved.production.foodPerSecond, production.foodPerSecond);
  }

  Object.keys(upgradePrices).forEach(key => {
    if (saved.upgradePrices && saved.upgradePrices[key] != null) {
      upgradePrices[key] = Math.max(1, Math.round(safeNumber(saved.upgradePrices[key], upgradePrices[key])));
    }
    if (saved.upgradeLevels && saved.upgradeLevels[key] != null) {
      upgradeLevels[key] = clampInt(saved.upgradeLevels[key], 0, maxKingdomLevel * upgradesPerCastleLevel, upgradeLevels[key]);
    }
  });

  Object.entries(troopTypes).forEach(([key, troop]) => {
    if (saved.troops && saved.troops[key] != null) {
      troop.count = Math.max(0, Math.round(safeNumber(saved.troops[key], troop.count)));
    }
  });

  if (saved.worldProgress) {
    Object.entries(worldAttackPoints).forEach(([mapNumber, enemies]) => {
      const savedEnemies = Array.isArray(saved.worldProgress[mapNumber]) ? saved.worldProgress[mapNumber] : [];
      enemies.forEach(enemy => {
        const savedEnemy = savedEnemies.find(item => item?.id === enemy.id);
        if (!savedEnemy) return;
        enemy.currentBattle = clampInt(savedEnemy.currentBattle, 0, enemy.battleCount, enemy.currentBattle);
        enemy.conquered = Boolean(savedEnemy.conquered || enemy.currentBattle >= enemy.battleCount);
        if (enemy.conquered) enemy.currentBattle = enemy.battleCount;
      });
    });
  }

  Object.keys(missionStats).forEach(key => {
    if (saved.missionStats && saved.missionStats[key] != null) {
      missionStats[key] = safeNumber(saved.missionStats[key], missionStats[key]);
    }
  });

  if (saved.activeMission && saved.activeMission.id && saved.activeMission.metric) {
    const template = missionTemplates.find(item => item.id === saved.activeMission.id);
    if (template && Object.prototype.hasOwnProperty.call(missionStats, saved.activeMission.metric)) {
      activeMission = {
        ...template,
        ...saved.activeMission,
        target: Math.max(1, Math.round(safeNumber(saved.activeMission.target, template.target))),
        startValue: safeNumber(saved.activeMission.startValue, 0),
      };
    }
  }
  lastMissionId = saved.lastMissionId || null;

  if (saved.events) {
    lastThroneEventId = saved.events.lastEventId || null;
    nextThroneEventAt = Number.isFinite(Number(saved.events.nextEventAt)) ? Number(saved.events.nextEventAt) : null;
    const pendingId = saved.events.pendingEventId || saved.events.activeEventId;
    pendingThroneEvent = throneEvents.find(event => event.id === pendingId) || null;
    restoredOpenEventId = saved.events.activeEventId || null;
  }

  const validScreens = ["trono", "reino", "harem", "mundo", "tropas"];
  restoredCurrentScreen = validScreens.includes(saved.currentScreen) ? saved.currentScreen : "trono";
  restoredMissionPanelOpen = Boolean(saved.ui?.missionPanelOpen);
  return true;
}

function resumeThroneEventSchedule(){
  if (pendingThroneEvent || activeThroneEvent) {
    nextThroneEventAt = null;
    updateThroneEventNotification();
    return;
  }

  if (nextThroneEventAt) {
    const remaining = Math.max(0, nextThroneEventAt - Date.now());
    scheduleNextThroneEvent(remaining);
    return;
  }

  scheduleNextThroneEvent();
}

function formatMissionReward(reward){
  const parts = [];
  if (reward?.gold) parts.push(`+${reward.gold} 🪙`);
  if (reward?.food) parts.push(`+${reward.food} 🍖`);
  if (reward?.gems) parts.push(`+${reward.gems} 💎`);
  return parts.join(" • ") || "—";
}

function getAvailableUpgradeSlots(){
  const limit = getUpgradeLimit();
  return Object.keys(upgradeLevels).reduce((total, priceKey) => {
    return total + Math.max(0, limit - upgradeLevels[priceKey]);
  }, 0);
}

function hasRemainingBattles(){
  return getOrderedEnemies().some(enemy => !enemy.conquered);
}

function isMissionTemplateEligible(template){
  if (template.id === "buy-upgrades") return getAvailableUpgradeSlots() > 0;
  if (template.id === "win-battle") return hasRemainingBattles();
  return true;
}

function buildMissionFromTemplate(template){
  const mission = { ...template };

  if (template.id === "buy-upgrades") {
    const availableSlots = getAvailableUpgradeSlots();
    mission.target = Math.min(template.target, availableSlots);
    mission.description = mission.target === 1
      ? "Compre 1 melhoria de casas ou fazendas."
      : `Compre ${mission.target} melhorias de casas ou fazendas.`;
  }

  return mission;
}

function chooseNextMission(){
  let pool = missionTemplates.filter(mission => isMissionTemplateEligible(mission) && mission.id !== lastMissionId);
  if (!pool.length) pool = missionTemplates.filter(isMissionTemplateEligible);
  if (!pool.length) return null;
  return pool[Math.floor(Math.random() * pool.length)];
}

function assignNextMission(){
  const template = chooseNextMission();
  if (!template) {
    activeMission = null;
    missionHudProgress.textContent = "—";
    missionReadyBadge.setAttribute("aria-hidden", "true");
    missionCollectBtn.disabled = true;
    missionTitle.textContent = "Sem missões disponíveis";
    missionDescription.textContent = "Continue avançando no reino para liberar novos objetivos.";
    missionProgressText.textContent = "—";
    missionProgressFill.style.width = "0%";
    missionRewardText.textContent = "—";
    return;
  }

  const mission = buildMissionFromTemplate(template);
  activeMission = {
    ...mission,
    startValue: missionStats[mission.metric] || 0,
  };
  lastMissionId = mission.id;
  if (missionFeedbackTimer) {
    clearTimeout(missionFeedbackTimer);
    missionFeedbackTimer = null;
  }
  missionFeedback.textContent = "";
  updateMissionUI();
  scheduleSave();
}

function getMissionProgress(){
  if (!activeMission) return 0;
  const currentValue = missionStats[activeMission.metric] || 0;
  return Math.max(0, Math.min(activeMission.target, currentValue - activeMission.startValue));
}

function isMissionComplete(){
  return Boolean(activeMission && getMissionProgress() >= activeMission.target);
}

function updateMissionUI(){
  if (!activeMission) return;
  const progress = getMissionProgress();
  const target = activeMission.target;
  const complete = progress >= target;
  const percent = target > 0 ? Math.min(100, Math.round((progress / target) * 100)) : 0;

  missionTitle.textContent = activeMission.title;
  missionDescription.textContent = activeMission.description;
  missionProgressText.textContent = `${progress} / ${target}`;
  missionProgressFill.style.width = `${percent}%`;
  missionRewardText.textContent = formatMissionReward(activeMission.reward);
  missionHudProgress.textContent = complete ? "Pronto" : `${progress}/${target}`;
  missionCollectBtn.disabled = !complete;
  missionCollectBtn.textContent = complete ? "COLETAR RECOMPENSA" : "MISSÃO EM ANDAMENTO";
  missionCollectBtn.classList.toggle("ready", complete);
  missionHudBtn.classList.toggle("ready", complete);
  missionReadyBadge.setAttribute("aria-hidden", complete ? "false" : "true");
}

function recordMissionProgress(metric, amount = 1){
  if (!Object.prototype.hasOwnProperty.call(missionStats, metric)) return;
  missionStats[metric] += Math.max(0, amount);
  updateMissionUI();
  scheduleSave();
}

function openMissionPanel(){
  if (!activeMission) assignNextMission();
  missionPanel.classList.add("open");
  missionPanel.setAttribute("aria-hidden", "false");
  updateMissionUI();
}

function closeMissionPanel(){
  missionPanel.classList.remove("open");
  missionPanel.setAttribute("aria-hidden", "true");
}

function collectMissionReward(){
  if (!activeMission || !isMissionComplete()) return;

  resources.gold += activeMission.reward?.gold || 0;
  resources.food += activeMission.reward?.food || 0;
  resources.gems += activeMission.reward?.gems || 0;
  updateResources();

  const rewardText = formatMissionReward(activeMission.reward);
  assignNextMission();
  missionFeedback.textContent = `Recompensa coletada: ${rewardText}`;
  missionFeedbackTimer = setTimeout(() => {
    missionFeedback.textContent = "";
    missionFeedbackTimer = null;
  }, 1200);
}

function getOrderedEnemies(){
  return Object.keys(worldAttackPoints)
    .map(Number)
    .sort((a, b) => a - b)
    .flatMap(mapNumber => worldAttackPoints[mapNumber]);
}

function isEnemyUnlocked(enemy){
  const enemies = getOrderedEnemies();
  const index = enemies.indexOf(enemy);
  if (index <= 0) return true;
  return enemies[index - 1].conquered;
}

function getBattleStats(enemy){
  const battleIndex = Math.min(enemy.currentBattle, enemy.battleCount - 1);
  return {
    force: Math.round(enemy.baseForce * Math.pow(battleForceMultiplier, battleIndex)),
    foodCost: Math.round(enemy.baseFoodCost * Math.pow(battleFoodMultiplier, battleIndex)),
  };
}

function formatInteger(value){
  return Math.floor(value).toLocaleString("pt-BR");
}

function getConqueredKingdomCount(){
  return getOrderedEnemies().filter(enemy => enemy.conquered).length;
}

function getCastleUpgradeRequirement(){
  if (kingdomLevel >= maxKingdomLevel) return null;
  return castleUpgradeRequirements[kingdomLevel + 1] || null;
}

function canUpgradeCastle(){
  const requirement = getCastleUpgradeRequirement();
  if (!requirement) return false;
  return getConqueredKingdomCount() >= requirement.kingdoms && resources.gold >= requirement.gold;
}

function updateCastleUpgradeState(){
  const conquered = getConqueredKingdomCount();
  const requirement = getCastleUpgradeRequirement();

  if (!requirement) {
    castleUpgradeTitle.textContent = "🏰 Castelo no nível máximo";
    castleLevelLabel.textContent = `Nível ${kingdomLevel} / ${maxKingdomLevel}`;
    castleRequirements.hidden = true;
    castleUpgradeBtn.disabled = true;
    castleUpgradeBtn.classList.remove("requirements-missing", "ready");
    castleUpgradeBtn.classList.add("maxed");
    castleUpgradeBtn.title = "Castelo no nível máximo";
    return;
  }

  const hasKingdoms = conquered >= requirement.kingdoms;
  const hasGold = resources.gold >= requirement.gold;
  const ready = hasKingdoms && hasGold;

  castleUpgradeTitle.textContent = `🏰 Melhorar para nível ${kingdomLevel + 1}`;
  castleLevelLabel.textContent = `Castelo ${kingdomLevel} → ${kingdomLevel + 1}`;
  castleRequirements.hidden = false;
  castleKingdomRequirement.textContent = `👑 Reinos: ${conquered} / ${requirement.kingdoms}`;
  castleGoldRequirement.textContent = `🪙 Ouro: ${formatInteger(resources.gold)} / ${formatInteger(requirement.gold)}`;

  castleKingdomRequirement.classList.toggle("met", hasKingdoms);
  castleGoldRequirement.classList.toggle("met", hasGold);
  castleUpgradeBtn.disabled = !ready;
  castleUpgradeBtn.classList.toggle("requirements-missing", !ready);
  castleUpgradeBtn.classList.toggle("ready", ready);
  castleUpgradeBtn.classList.remove("maxed");

  const missing = [];
  if (!hasKingdoms) missing.push(`${requirement.kingdoms - conquered} reino(s)`);
  if (!hasGold) missing.push(`${formatInteger(requirement.gold - resources.gold)} ouro`);
  castleUpgradeBtn.title = ready ? "Melhorar castelo" : `Falta: ${missing.join(" • ")}`;
}

function upgradeCastle(){
  const requirement = getCastleUpgradeRequirement();
  if (!requirement || !canUpgradeCastle()) return;

  resources.gold = Math.max(0, resources.gold - requirement.gold);
  kingdomLevel += 1;

  updateResources();
  updateKingdomLevel();
}

function getBarracksUpgradeRequirement(){
  if (troopsLevel >= maxTroopsLevel) return null;
  return barracksUpgradeRequirements[troopsLevel + 1] || null;
}

function canUpgradeBarracks(){
  const requirement = getBarracksUpgradeRequirement();
  if (!requirement) return false;
  const targetLevel = troopsLevel + 1;
  return kingdomLevel >= targetLevel && resources.gold >= requirement.gold;
}

function updateBarracksUpgradeState(){
  const requirement = getBarracksUpgradeRequirement();

  if (!requirement) {
    barracksUpgradeTitle.textContent = "⚔️ Quartel no nível máximo";
    barracksLevelLabel.textContent = `Nível ${troopsLevel} / ${maxTroopsLevel}`;
    barracksRequirements.hidden = true;
    troopsLevelBtn.disabled = true;
    troopsLevelBtn.classList.remove("requirements-missing", "ready");
    troopsLevelBtn.classList.add("maxed");
    troopsLevelBtn.title = "Quartel no nível máximo";
    return;
  }

  const targetLevel = troopsLevel + 1;
  const hasCastle = kingdomLevel >= targetLevel;
  const hasGold = resources.gold >= requirement.gold;
  const ready = hasCastle && hasGold;

  barracksUpgradeTitle.textContent = `⚔️ Melhorar para nível ${targetLevel}`;
  barracksLevelLabel.textContent = `Quartel ${troopsLevel} → ${targetLevel}`;
  barracksRequirements.hidden = false;
  barracksCastleRequirement.textContent = `🏰 Castelo: ${kingdomLevel} / ${targetLevel}`;
  barracksGoldRequirement.textContent = `🪙 Ouro: ${formatInteger(resources.gold)} / ${formatInteger(requirement.gold)}`;

  barracksCastleRequirement.classList.toggle("met", hasCastle);
  barracksGoldRequirement.classList.toggle("met", hasGold);
  troopsLevelBtn.disabled = !ready;
  troopsLevelBtn.classList.toggle("requirements-missing", !ready);
  troopsLevelBtn.classList.toggle("ready", ready);
  troopsLevelBtn.classList.remove("maxed");

  const missing = [];
  if (!hasCastle) missing.push(`Castelo nível ${targetLevel}`);
  if (!hasGold) missing.push(`${formatInteger(requirement.gold - resources.gold)} ouro`);
  troopsLevelBtn.title = ready ? "Melhorar quartel" : `Falta: ${missing.join(" • ")}`;
}

function upgradeBarracks(){
  const requirement = getBarracksUpgradeRequirement();
  if (!requirement || !canUpgradeBarracks()) return;

  resources.gold = Math.max(0, resources.gold - requirement.gold);
  troopsLevel += 1;

  updateResources();
  updateTroopsLevel();
}

function updateResources(){
  goldValue.textContent = Math.floor(resources.gold);
  foodValue.textContent = Math.floor(resources.food);
  gemValue.textContent = Math.floor(resources.gems);
  updateUpgradeAffordability();
  updateTroopAffordability();
  updateWarAffordability();
  updateEventAffordability();
  updateCastleUpgradeState();
  updateBarracksUpgradeState();
  scheduleSave();
}

function getUpgradeLimit(){
  return kingdomLevel * upgradesPerCastleLevel;
}

function isUpgradeLocked(priceKey){
  return upgradeLevels[priceKey] >= getUpgradeLimit();
}

function getRequiredCastleLevel(priceKey){
  return Math.min(maxKingdomLevel, Math.floor(upgradeLevels[priceKey] / upgradesPerCastleLevel) + 1);
}

function setUpgradeLabel(levelLabel, priceLabel, priceKey){
  const level = upgradeLevels[priceKey];
  const limit = getUpgradeLimit();
  levelLabel.textContent = `Nv ${level}/${limit}`;

  if (isUpgradeLocked(priceKey)) {
    priceLabel.textContent = kingdomLevel >= maxKingdomLevel
      ? "MÁXIMO"
      : `Requer Castelo ${getRequiredCastleLevel(priceKey)} 🏰`;
  } else {
    priceLabel.textContent = `${upgradePrices[priceKey]} 🪙`;
  }
}

function updateProductionLabels(){
  goldPerClickLabel.textContent = `+${production.goldPerClick}`;
  goldPerSecondLabel.textContent = `+${production.goldPerSecond}/s`;
  foodPerClickLabel.textContent = `+${production.foodPerClick}`;
  foodPerSecondLabel.textContent = `+${production.foodPerSecond}/s`;
  goldClickHint.textContent = `+${production.goldPerClick} por clique`;
  foodClickHint.textContent = `+${production.foodPerClick} por clique`;
  goldPerSecondTop.textContent = `${production.goldPerSecond}/s`;
  foodPerSecondTop.textContent = `${production.foodPerSecond}/s`;

  setUpgradeLabel(houseClickLevelLabel, houseClickPriceLabel, "houseClick");
  setUpgradeLabel(houseSecondLevelLabel, houseSecondPriceLabel, "houseSecond");
  setUpgradeLabel(farmClickLevelLabel, farmClickPriceLabel, "farmClick");
  setUpgradeLabel(farmSecondLevelLabel, farmSecondPriceLabel, "farmSecond");
  updateUpgradeAffordability();
}

function nextUpgradePrice(currentPrice){
  return Math.round(currentPrice * upgradePriceMultiplier);
}

function updateUpgradeAffordability(){
  const gold = Math.floor(resources.gold);
  const configs = [
    [houseClickUpgradeBtn, "houseClick"],
    [houseSecondUpgradeBtn, "houseSecond"],
    [farmClickUpgradeBtn, "farmClick"],
    [farmSecondUpgradeBtn, "farmSecond"],
  ];

  configs.forEach(([button, priceKey]) => {
    const locked = isUpgradeLocked(priceKey);
    button.disabled = locked;
    button.classList.toggle("castle-locked", locked);
    button.classList.toggle("unaffordable", !locked && gold < upgradePrices[priceKey]);

    if (locked) {
      button.title = kingdomLevel >= maxKingdomLevel
        ? "Nível máximo desta melhoria"
        : `Requer Castelo nível ${getRequiredCastleLevel(priceKey)}`;
    } else {
      button.title = `${upgradePrices[priceKey]} de ouro`;
    }
  });
}

function buyUpgrade(button, priceKey, applyUpgrade){
  if (isUpgradeLocked(priceKey)) {
    button.classList.remove("castle-blocked-hit");
    void button.offsetWidth;
    button.classList.add("castle-blocked-hit");
    return;
  }

  const price = upgradePrices[priceKey];
  if (resources.gold < price) {
    button.classList.remove("insufficient");
    void button.offsetWidth;
    button.classList.add("insufficient");
    return;
  }

  resources.gold -= price;
  applyUpgrade();
  upgradeLevels[priceKey] += 1;
  upgradePrices[priceKey] = nextUpgradePrice(price);
  recordMissionProgress("upgradesBought", 1);
  updateResources();
  updateProductionLabels();
}

function formatEventRequirement(option){
  const parts = [];
  if (option.cost?.gold) parts.push(`${option.cost.gold} ouro`);
  if (option.cost?.food) parts.push(`${option.cost.food} comida`);
  if (option.requires?.soldiers) parts.push(`${option.requires.soldiers} soldados`);
  return parts.join(" • ");
}

function canChooseEventOption(option){
  if (option.cost?.gold && resources.gold < option.cost.gold) return false;
  if (option.cost?.food && resources.food < option.cost.food) return false;
  if (option.requires?.soldiers && getTotalSoldiers() < option.requires.soldiers) return false;
  return true;
}

function updateEventAffordability(){
  if (!activeThroneEvent || !throneEventPanel.classList.contains("open")) return;
  eventOptions.querySelectorAll(".event-option-btn").forEach((button, index) => {
    const option = activeThroneEvent.options[index];
    if (!option) return;

    if (eventChoiceLocked) {
      button.disabled = true;
      button.classList.add("choice-locked");
      return;
    }

    const available = canChooseEventOption(option);
    button.classList.toggle("unavailable", !available);
    button.disabled = !available;
    button.title = available ? "Escolher opção" : `Falta: ${formatEventRequirement(option)}`;
  });
}

function getCurrentScreenName(){
  return document.querySelector(".screen.active")?.dataset.screen || "trono";
}

function chooseNextThroneEvent(){
  let pool = throneEvents.filter(event => event.id !== lastThroneEventId);
  if (!pool.length) pool = throneEvents;
  return pool[Math.floor(Math.random() * pool.length)];
}

function randomThroneEventDelay(){
  return Math.floor(throneEventMinDelay + Math.random() * (throneEventMaxDelay - throneEventMinDelay + 1));
}

function updateThroneEventNotification(){
  const hasPending = Boolean(pendingThroneEvent || activeThroneEvent);
  const onThrone = getCurrentScreenName() === "trono";
  const shouldAlert = hasPending && !onThrone;

  throneEventBadge?.classList.toggle("visible", shouldAlert);
  throneEventBadge?.setAttribute("aria-hidden", shouldAlert ? "false" : "true");
  throneNavItem?.classList.toggle("attention", shouldAlert);

  eventTestBtn.classList.toggle("pending", hasPending && !activeThroneEvent);
  if (activeThroneEvent) {
    eventTestBtn.textContent = "Aberto";
  } else if (pendingThroneEvent) {
    eventTestBtn.textContent = "Novo evento";
  } else {
    eventTestBtn.textContent = "Eventos";
  }
  scheduleSave();
}

function scheduleNextThroneEvent(delayOverride = null){
  if (throneEventTimer) clearTimeout(throneEventTimer);
  if (pendingThroneEvent || activeThroneEvent) {
    throneEventTimer = null;
    nextThroneEventAt = null;
    scheduleSave();
    return;
  }

  const delay = delayOverride == null ? randomThroneEventDelay() : Math.max(0, Math.round(delayOverride));
  nextThroneEventAt = Date.now() + delay;
  scheduleSave();

  throneEventTimer = setTimeout(() => {
    throneEventTimer = null;
    nextThroneEventAt = null;
    if (pendingThroneEvent || activeThroneEvent) return;

    const event = chooseNextThroneEvent();
    pendingThroneEvent = event;
    lastThroneEventId = event.id;
    updateThroneEventNotification();
  }, delay);
}

function hideThroneEventPanel(){
  if (eventResolutionTimer) {
    clearTimeout(eventResolutionTimer);
    eventResolutionTimer = null;
  }

  if (activeThroneEvent && !eventChoiceLocked) {
    pendingThroneEvent = activeThroneEvent;
  }

  activeThroneEvent = null;
  eventChoiceLocked = false;
  throneEventPanel.classList.remove("open");
  throneEventPanel.setAttribute("aria-hidden", "true");
  eventFeedback.textContent = "";
  eventFeedback.classList.remove("success", "error");
  eventOptions.innerHTML = "";
  updateThroneEventNotification();
}

function dismissThroneEvent(){
  if (eventResolutionTimer) {
    clearTimeout(eventResolutionTimer);
    eventResolutionTimer = null;
  }

  activeThroneEvent = null;
  pendingThroneEvent = null;
  eventChoiceLocked = false;
  throneEventPanel.classList.remove("open");
  throneEventPanel.setAttribute("aria-hidden", "true");
  eventFeedback.textContent = "";
  eventFeedback.classList.remove("success", "error");
  eventOptions.innerHTML = "";
  updateThroneEventNotification();
  scheduleNextThroneEvent();
}

function applyEventOption(option){
  if (eventChoiceLocked) return;

  if (!canChooseEventOption(option)) {
    eventFeedback.textContent = "Recursos insuficientes para essa escolha.";
    eventFeedback.classList.remove("success");
    eventFeedback.classList.add("error");
    return;
  }

  eventChoiceLocked = true;
  eventOptions.querySelectorAll("button").forEach(button => {
    button.disabled = true;
    button.classList.add("choice-locked");
  });

  resources.gold = Math.max(0, resources.gold - (option.cost?.gold || 0));
  resources.food = Math.max(0, resources.food - (option.cost?.food || 0));
  resources.gold += option.reward?.gold || 0;
  resources.food += option.reward?.food || 0;

  if (option.reward?.swordsmen) {
    const gainedSwordsmen = Math.max(0, Math.round(option.reward.swordsmen));
    troopTypes.swordsman.count += gainedSwordsmen;
    recordMissionProgress("forceAdded", gainedSwordsmen * troopTypes.swordsman.force);
  }

  pendingThroneEvent = null;
  updateResources();
  updateArmyDisplay();

  eventFeedback.textContent = option.detail || "Decisão concluída.";
  eventFeedback.classList.remove("error");
  eventFeedback.classList.add("success");
  updateThroneEventNotification();

  eventResolutionTimer = setTimeout(() => {
    activeThroneEvent = null;
    eventChoiceLocked = false;
    throneEventPanel.classList.remove("open");
    throneEventPanel.setAttribute("aria-hidden", "true");
    eventFeedback.textContent = "";
    eventFeedback.classList.remove("success", "error");
    eventOptions.innerHTML = "";
    updateThroneEventNotification();
    scheduleNextThroneEvent();
  }, 1100);
}

function openThroneEvent(event){
  if (!event || activeThroneEvent) return;
  if (eventResolutionTimer) {
    clearTimeout(eventResolutionTimer);
    eventResolutionTimer = null;
  }

  activeThroneEvent = event;
  pendingThroneEvent = event;
  eventChoiceLocked = false;
  eventCategory.textContent = event.category;
  eventTitle.textContent = event.title;
  eventDescription.textContent = event.description;
  eventFeedback.textContent = "";
  eventFeedback.classList.remove("success", "error");
  eventOptions.innerHTML = "";

  event.options.forEach((option, index) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "event-option-btn";
    button.dataset.optionIndex = index;
    const label = document.createElement("strong");
    label.textContent = option.label;
    const detail = document.createElement("small");
    detail.textContent = option.detail;
    button.append(label, detail);
    button.addEventListener("click", () => applyEventOption(option));
    eventOptions.appendChild(button);
  });

  throneEventPanel.classList.add("open");
  throneEventPanel.setAttribute("aria-hidden", "false");
  updateThroneEventNotification();
  updateEventAffordability();
}

function openPendingThroneEvent(){
  if (activeThroneEvent) return;
  if (!pendingThroneEvent) return;
  openThroneEvent(pendingThroneEvent);
}

function generateTestThroneEvent(){
  if (getCurrentScreenName() !== "trono") showScreen("trono");
  if (activeThroneEvent) return;

  if (pendingThroneEvent) {
    openPendingThroneEvent();
    return;
  }

  if (throneEventTimer) {
    clearTimeout(throneEventTimer);
    throneEventTimer = null;
  }

  const event = chooseNextThroneEvent();
  pendingThroneEvent = event;
  lastThroneEventId = event.id;
  updateThroneEventNotification();
  openPendingThroneEvent();
}

function getTotalSoldiers(){
  return Object.values(troopTypes).reduce((sum, troop) => sum + troop.count, 0);
}

function getTotalForce(){
  return Object.values(troopTypes).reduce((sum, troop) => sum + troop.count * troop.force, 0);
}

function applyCasualties(rate){
  let totalLosses = 0;
  const lossesByType = {};

  Object.entries(troopTypes).forEach(([key, troop]) => {
    const rawLosses = Math.round(troop.count * rate);
    const losses = Math.max(0, Math.min(troop.count, rawLosses));

    troop.count = Math.max(0, troop.count - losses);
    lossesByType[key] = losses;
    totalLosses += losses;
  });

  return { totalLosses, lossesByType };
}

function updateArmyDisplay(){
  swordsmanCount.textContent = troopTypes.swordsman.count;
  archerCount.textContent = troopTypes.archer.count;
  knightCount.textContent = troopTypes.knight.count;
  totalSoldiersValue.textContent = getTotalSoldiers();
  totalForceValue.textContent = getTotalForce();
  updateTroopAffordability();
  updateWarAffordability();
  updateEventAffordability();
  scheduleSave();
}

function updateTroopAffordability(){
  const buttons = [
    [buySwordsmanBtn, troopTypes.swordsman],
    [buyArcherBtn, troopTypes.archer],
    [buyKnightBtn, troopTypes.knight],
  ];

  buttons.forEach(([button, troop]) => {
    if (!button) return;
    const locked = troopsLevel < troop.unlockLevel;
    button.classList.toggle("locked", locked);
    button.classList.toggle("unaffordable", !locked && resources.food < troop.cost);
    button.title = locked ? `Desbloqueia no Quartel nível ${troop.unlockLevel}` : `${troop.cost} de comida`;
  });
}

function recruitTroop(typeKey, button){
  const troop = troopTypes[typeKey];
  if (troopsLevel < troop.unlockLevel || resources.food < troop.cost) {
    button.classList.remove("insufficient");
    void button.offsetWidth;
    button.classList.add("insufficient");
    return;
  }

  resources.food -= troop.cost;
  troop.count += 1;
  recordMissionProgress("soldiersRecruited", 1);
  recordMissionProgress("forceAdded", troop.force);
  updateResources();
  updateArmyDisplay();
}

function updateThroneLevel(){
  throneScreen.style.backgroundImage = `url("assets/throne/level-${throneLevel}.png")`;
  throneLevelBtn.textContent = `Trono • Nível ${throneLevel}`;
  scheduleSave();
}

function updateKingdomLevel(){
  kingdomScreen.style.backgroundImage = `url("assets/kingdom/level-${kingdomLevel}.png")`;
  updateProductionLabels();
  updateCastleUpgradeState();
  updateBarracksUpgradeState();
  scheduleSave();
}

function renderWarProgress(enemy){
  warProgressDots.innerHTML = "";
  for (let i = 0; i < enemy.battleCount; i += 1) {
    const dot = document.createElement("span");
    dot.className = "war-progress-dot";
    if (i < enemy.currentBattle) dot.classList.add("done");
    if (!enemy.conquered && i === enemy.currentBattle) dot.classList.add("current");
    warProgressDots.appendChild(dot);
  }
}

function updateWarAffordability(){
  if (!selectedEnemy || !warAttackBtn) return;

  renderWarProgress(selectedEnemy);
  if (selectedEnemy.conquered) {
    warTitle.textContent = `${selectedEnemy.label} • CONQUISTADO ✓`;
    enemyForceValue.textContent = "—";
    warFoodCostValue.textContent = "—";
    warMenu.classList.add("conquered");
    warAttackBtn.disabled = true;
    return;
  }

  const stats = getBattleStats(selectedEnemy);
  const currentFood = Math.floor(resources.food);
  const currentForce = getTotalForce();
  const canAfford = currentFood >= stats.foodCost;

  warMenu.classList.remove("conquered");
  warTitle.textContent = `${selectedEnemy.label} • Batalha ${selectedEnemy.currentBattle + 1}/${selectedEnemy.battleCount}`;
  enemyForceValue.textContent = `${stats.force} / ${currentForce}`;
  warFoodCostValue.textContent = `${stats.foodCost} / ${currentFood}`;
  warAttackBtn.classList.toggle("unaffordable", !canAfford);
  warAttackBtn.title = canAfford ? "Iniciar guerra" : "Comida insuficiente";
}

function openWarMenu(enemy){
  if (!isEnemyUnlocked(enemy)) return;
  selectedEnemy = enemy;
  warFeedback.textContent = "";
  warFeedback.classList.remove("victory", "defeat");
  warAttackBtn.disabled = false;
  warMenu.classList.add("open");
  warMenu.setAttribute("aria-hidden", "false");
  updateWarAffordability();
}

function closeWarMenu(){
  selectedEnemy = null;
  warMenu.classList.remove("open", "conquered");
  warMenu.setAttribute("aria-hidden", "true");
  warFeedback.textContent = "";
  warFeedback.classList.remove("victory", "defeat");
  warAttackBtn.disabled = false;
  attackButtonsLayer.querySelectorAll(".attack-btn").forEach(item => item.classList.remove("selected"));
}

function startSelectedWar(){
  if (!selectedEnemy || selectedEnemy.conquered || !isEnemyUnlocked(selectedEnemy)) return;

  const stats = getBattleStats(selectedEnemy);
  const playerForceBeforeBattle = getTotalForce();

  if (playerForceBeforeBattle <= 0) {
    warFeedback.textContent = "Você não possui tropas";
    warFeedback.classList.remove("victory", "defeat");
    return;
  }

  if (resources.food < stats.foodCost) {
    warFeedback.textContent = "Comida insuficiente";
    warFeedback.classList.remove("victory", "defeat");
    return;
  }

  resources.food = Math.max(0, resources.food - stats.foodCost);

  const victory = playerForceBeforeBattle >= stats.force;
  if (victory) recordMissionProgress("battlesWon", 1);
  const casualtyRate = victory ? victoryCasualtyRate : defeatCasualtyRate;
  const { totalLosses } = applyCasualties(casualtyRate);

  if (victory) {
    selectedEnemy.currentBattle = Math.min(selectedEnemy.battleCount, selectedEnemy.currentBattle + 1);
    if (selectedEnemy.currentBattle >= selectedEnemy.battleCount) {
      selectedEnemy.conquered = true;
    }
  }

  updateResources();
  updateArmyDisplay();

  const remainingForce = getTotalForce();
  const percent = Math.round(casualtyRate * 100);
  const destroyedText = getTotalSoldiers() === 0 ? " • Exército destruído" : ` • Força restante ${remainingForce}`;

  warFeedback.classList.toggle("victory", victory);
  warFeedback.classList.toggle("defeat", !victory);

  if (victory && selectedEnemy.conquered) {
    warFeedback.textContent = `CONQUISTADO ✓ • ${percent}% de baixas • ${totalLosses} soldados perdidos${destroyedText}`;
    renderAttackButtons();
  } else if (victory) {
    warFeedback.textContent = `VITÓRIA • ${percent}% de baixas • ${totalLosses} soldados perdidos${destroyedText}`;
  } else {
    warFeedback.textContent = `DERROTA • ${percent}% de baixas • ${totalLosses} soldados perdidos${destroyedText}`;
  }

  updateWarAffordability();

  // Em vitória intermediária, o jogador pode seguir direto para a próxima batalha.
  // Em derrota, continua exatamente na mesma etapa da campanha.
  warAttackBtn.disabled = selectedEnemy.conquered;
}

function renderAttackButtons(){
  const points = worldAttackPoints[worldMap] || [];
  attackButtonsLayer.innerHTML = "";

  points.forEach(point => {
    if (point.conquered) {
      const marker = document.createElement("div");
      marker.className = "conquered-marker";
      marker.dataset.sourceX = point.x;
      marker.dataset.sourceY = point.y;
      marker.setAttribute("aria-label", `${point.label} conquistado`);
      marker.textContent = "✓";
      attackButtonsLayer.appendChild(marker);
      return;
    }

    const unlocked = isEnemyUnlocked(point);
    const button = document.createElement("button");
    button.type = "button";
    button.className = unlocked ? "attack-btn" : "attack-btn locked";
    button.dataset.sourceX = point.x;
    button.dataset.sourceY = point.y;
    button.dataset.enemy = point.id;
    button.disabled = !unlocked;

    if (unlocked) {
      button.setAttribute("aria-label", `${point.label} disponível para ataque`);
      button.title = point.label;
      button.textContent = "⚔";
      button.addEventListener("click", () => {
        attackButtonsLayer.querySelectorAll(".attack-btn").forEach(item => item.classList.remove("selected"));
        button.classList.add("selected");
        openWarMenu(point);
      });
    } else {
      button.setAttribute("aria-label", `${point.label} bloqueado`);
      button.title = "Conquiste o reino anterior primeiro";
      button.textContent = "🔒";
    }

    attackButtonsLayer.appendChild(button);
  });

  positionAttackButtons();
}

function positionAttackButtons(){
  const sourceWidth = 864;
  const sourceHeight = 1536;
  const width = worldScreen.clientWidth;
  const height = worldScreen.clientHeight;
  if (!width || !height) return;

  const scale = Math.max(width / sourceWidth, height / sourceHeight);
  const renderedWidth = sourceWidth * scale;
  const renderedHeight = sourceHeight * scale;
  const offsetX = (width - renderedWidth) / 2;
  const offsetY = (height - renderedHeight) / 2;

  attackButtonsLayer.querySelectorAll(".attack-btn, .conquered-marker").forEach(item => {
    const sourceX = Number(item.dataset.sourceX);
    const sourceY = Number(item.dataset.sourceY);
    item.style.left = `${offsetX + sourceX * scale}px`;
    item.style.top = `${offsetY + sourceY * scale}px`;
  });
}

function updateWorldMap(){
  closeWarMenu();
  worldScreen.style.backgroundImage = `url("assets/world/map-${worldMap}.png")`;
  worldMapBtn.textContent = `Mundo • Mapa ${worldMap}`;
  renderAttackButtons();
  scheduleSave();
}

function updateTroopsLevel(){
  troopsScreen.style.backgroundImage = `url("assets/troops/level-${troopsLevel}.png")`;
  updateBarracksUpgradeState();
  updateTroopAffordability();
  scheduleSave();
}

function showScreen(name){
  closeMissionPanel();
  if (name !== "mundo") closeWarMenu();
  if (name !== "trono" && activeThroneEvent && !eventChoiceLocked) hideThroneEventPanel();
  screens.forEach(screen => screen.classList.toggle("active", screen.dataset.screen === name));
  navItems.forEach(item => item.classList.toggle("active", item.dataset.target === name));
  if (name === "mundo") requestAnimationFrame(positionAttackButtons);
  updateThroneEventNotification();
  scheduleSave();
}

navItems.forEach(item => item.addEventListener("click", () => showScreen(item.dataset.target)));

warCloseBtn.addEventListener("click", closeWarMenu);
warAttackBtn.addEventListener("click", startSelectedWar);
eventTestBtn.addEventListener("click", generateTestThroneEvent);
eventCloseBtn.addEventListener("click", dismissThroneEvent);
missionHudBtn.addEventListener("click", openMissionPanel);
missionCloseBtn.addEventListener("click", closeMissionPanel);
missionCollectBtn.addEventListener("click", collectMissionReward);
resetGameBtn.addEventListener("click", resetGameProgress);

throneLevelBtn.addEventListener("click", () => {
  throneLevel = throneLevel >= maxThroneLevel ? 1 : throneLevel + 1;
  updateThroneLevel();
});

castleUpgradeBtn.addEventListener("click", upgradeCastle);

worldMapBtn.addEventListener("click", () => {
  worldMap = worldMap >= maxWorldMap ? 1 : worldMap + 1;
  updateWorldMap();
});

troopsLevelBtn.addEventListener("click", upgradeBarracks);

testSoldiersBtn.addEventListener("click", () => {
  troopTypes.swordsman.count += 50;
  updateArmyDisplay();
});

buySwordsmanBtn.addEventListener("click", () => recruitTroop("swordsman", buySwordsmanBtn));
buyArcherBtn.addEventListener("click", () => recruitTroop("archer", buyArcherBtn));
buyKnightBtn.addEventListener("click", () => recruitTroop("knight", buyKnightBtn));

collectGoldBtn.addEventListener("click", () => {
  resources.gold += production.goldPerClick;
  recordMissionProgress("goldProduced", production.goldPerClick);
  recordMissionProgress("goldClicks", 1);
  updateResources();
});
testGoldBtn.addEventListener("click", () => { resources.gold += 1000; updateResources(); });
collectFoodBtn.addEventListener("click", () => {
  resources.food += production.foodPerClick;
  recordMissionProgress("foodProduced", production.foodPerClick);
  recordMissionProgress("foodClicks", 1);
  updateResources();
});
houseClickUpgradeBtn.addEventListener("click", () => { buyUpgrade(houseClickUpgradeBtn, "houseClick", () => { production.goldPerClick += 1; }); });
houseSecondUpgradeBtn.addEventListener("click", () => { buyUpgrade(houseSecondUpgradeBtn, "houseSecond", () => { production.goldPerSecond += 1; }); });
farmClickUpgradeBtn.addEventListener("click", () => { buyUpgrade(farmClickUpgradeBtn, "farmClick", () => { production.foodPerClick += 1; }); });
farmSecondUpgradeBtn.addEventListener("click", () => { buyUpgrade(farmSecondUpgradeBtn, "farmSecond", () => { production.foodPerSecond += 1; }); });

window.addEventListener("resize", positionAttackButtons);


if (testFoodBtn) {
  testFoodBtn.addEventListener("click", () => {
    resources.food += 1000;
    updateResources();
  });
}

loadGameState();

updateResources();
updateProductionLabels();
updateThroneLevel();
updateKingdomLevel();
updateWorldMap();
updateTroopsLevel();
updateArmyDisplay();

if (activeMission) {
  updateMissionUI();
} else {
  assignNextMission();
}

showScreen(restoredCurrentScreen);

if (restoredOpenEventId && restoredCurrentScreen === "trono" && pendingThroneEvent) {
  openPendingThroneEvent();
} else {
  updateThroneEventNotification();
}

if (restoredMissionPanelOpen) openMissionPanel();

saveReady = true;
resumeThroneEventSchedule();
saveGameState();

setInterval(() => {
  resources.gold += production.goldPerSecond;
  resources.food += production.foodPerSecond;
  if (production.goldPerSecond > 0) recordMissionProgress("goldProduced", production.goldPerSecond);
  if (production.foodPerSecond > 0) recordMissionProgress("foodProduced", production.foodPerSecond);
  updateResources();
}, 1000);

setInterval(saveGameState, 5000);
window.addEventListener("pagehide", saveGameState);
window.addEventListener("beforeunload", saveGameState);
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "hidden") saveGameState();
});
