# Jogo V3 — Interface Base

## O que existe agora
- Tela Trono com 10 fundos e coleta de ouro/comida
- Tela Reino com 10 fundos, botão de castelo e melhorias de casas/fazendas
- Tela Mundo com 3 mapas e botão para alternar entre eles
- Menu superior fixo com ouro, comida e gemas
- Produção por segundo exibida abaixo de ouro e comida
- Menu inferior fixo para navegação
- Tela Tropas/Quartel com 10 fundos e botão para alternar níveis
- Botões circulares de ataque posicionados abaixo dos reinos inimigos nos 3 mapas

## Preços atuais das melhorias do Reino
- Casa — ouro por clique: 40 ouro inicial
- Casa — ouro por segundo: 60 ouro inicial
- Fazenda — comida por clique: 40 ouro inicial
- Fazenda — comida por segundo: 60 ouro inicial
- Após cada compra, o preço aumenta 25% e é arredondado para o inteiro mais próximo.

## Recrutamento inicial
- Espadachim: 3 comida, força 1, desbloqueado no Quartel 1
- Arqueiro: 7 comida, força 2, desbloqueado no Quartel 2
- Cavaleiro: 14 comida, força 4, desbloqueado no Quartel 3
- A tela Tropas mostra quantidade total de soldados e força total do exército.

## Guerras
- Tocar em um reino inimigo abre um menu de guerra.
- O menu mostra apenas a força inimiga e o custo em comida.
- Primeiro custo: 500 comida. Custos seguintes crescem aproximadamente 25%.
- O botão Atacar desconta a comida.
- A resolução da batalha fica preparada para a próxima etapa.

## Baixas de batalha
- Vitória: 20% de baixas em cada categoria de tropa.
- Derrota: 40% de baixas em cada categoria de tropa.
- Cada perda usa `Math.round` e sempre resulta em número inteiro.
- Nenhuma categoria pode ficar abaixo de 0 soldados.
- Vitória ocorre quando a força do jogador é maior ou igual à força inimiga.

- Botão de teste no Trono: +1000 de ouro por clique.

- Menu de guerra mostra comida no formato disponível / necessário (ex.: 500 / 1500).

## Campanhas por castelo
- Cada castelo possui entre 3 e 5 batalhas.
- O progresso aparece em bolinhas no menu de ataque.
- Vitória preenche uma bolinha; derrota não apaga progresso e mantém a mesma etapa.
- Dentro do mesmo castelo, força inimiga cresce 12% por batalha e custo em comida 15%.
- Após a última vitória, o castelo fica conquistado e recebe um marcador ✓ no mapa.
- Recompensas ainda não foram implementadas.

- Botão de teste no Quartel: +50 soldados (Espadachins), atualizando força e quantidade total.

- Progressão dos inimigos é sequencial: apenas o próximo castelo fica atacável; os demais exibem cadeado até a conquista completa do anterior.

## Eventos do Trono — Parte 1
- Botão manual `Gerar evento` para testes.
- Painel central com título, descrição, duas decisões e X para fechar.
- 5 eventos: Mercadores, Boa colheita, Mercenários, Camponeses e Caravana saqueada.
- Efeitos usam apenas ouro, comida e soldados.
- Apenas um evento pode ficar aberto por vez.
- Frequência automática ainda não foi ativada.

- Ao escolher uma opção de evento, a decisão é travada imediatamente; a outra opção não pode ser selecionada antes do painel fechar.

## Eventos do Trono — Parte 2
- Eventos automáticos são sorteados entre 2 e 5 minutos.
- Só existe um evento pendente/aberto por vez.
- Fora do Trono, aparece um `!` no botão de navegação do Trono.
- No Trono, o botão muda para `Novo evento` e o jogador escolhe quando abrir.
- Sair do Trono não perde um evento ainda não resolvido.
- Fechar pelo X ignora o evento e inicia uma nova contagem.
- Resolver o evento inicia a próxima contagem somente após o resultado fechar.

- Quando há evento pendente, o símbolo do Trono vibra junto com o aviso ! para chamar atenção do jogador.

## Ajuste de ritmo dos Eventos do Trono
- Intervalo automático: 1min30s a 3min.
- Recompensas iniciais reduzidas para não competir com a economia principal.
- Ouro por evento limitado a no máximo 90 nesta fase.
- Comida e mercenários também foram reduzidos; escalonamento por progresso ficará para etapa futura.


## Missões — Parte 1
- Uma missão ativa por vez.
- 8 tipos iniciais: produzir ouro, produzir comida, recrutar soldados, comprar melhorias, vencer batalha, aumentar força, coletar ouro e coletar comida.
- Progresso é automático e começa a contar a partir do momento em que a missão é sorteada.
- Ganhos pelos botões de teste não contam para as missões de produção/recrutamento.
- Ao concluir, o botão de Missão recebe aviso visual e a recompensa precisa ser coletada manualmente.
- Após coletar, uma nova missão é sorteada sem repetir imediatamente a anterior.
- Recompensas iniciais são pequenas (até 80 de ouro / 70 de comida) e poderão escalar com o progresso no futuro.

## Limite de melhorias por Castelo
- Cada uma das 4 melhorias (ouro/clique, ouro/seg, comida/clique, comida/seg) possui limite próprio.
- O limite é de 10 compras por nível do Castelo: Castelo 1 = até 10, Castelo 2 = até 20, ... Castelo 10 = até 100.
- Ao atingir o limite, o botão fica bloqueado e informa qual nível de Castelo é necessário.
- Ao subir o Castelo, os próximos 10 níveis são liberados imediatamente.

## Missões elegíveis
- Missão de melhorias só entra no sorteio quando ainda existem níveis de casas/fazendas liberados pelo Castelo.
- A meta se adapta ao espaço disponível: se só restar 1 melhoria, a missão pede 1 em vez de 2.
- Missão de vitória em batalha só entra enquanto existir alguma batalha ainda não conquistada.
- Produção, coleta, recrutamento e aumento de força permanecem sempre elegíveis.

## Evolução real do Castelo
- O botão de melhorar Castelo deixou de ser gratuito/de teste.
- Cada evolução exige simultaneamente uma quantidade mínima de reinos totalmente conquistados e ouro.
- Reinos só contam após concluir todas as batalhas da campanha daquele inimigo.
- Custos: Nv2 = 2 reinos + 12.000 ouro; Nv3 = 4 + 28.000; Nv4 = 6 + 50.000; Nv5 = 8 + 80.000; Nv6 = 10 + 120.000; Nv7 = 12 + 170.000; Nv8 = 15 + 230.000; Nv9 = 18 + 300.000; Nv10 = 22 + 400.000.
- O botão mostra progresso atual de reinos e ouro e só é habilitado quando ambos os requisitos são cumpridos.
- Ao evoluir, o ouro é descontado, a imagem do Reino avança e mais 10 níveis de cada melhoria de casas/fazendas são liberados.
- No nível 10, o botão mostra Castelo no nível máximo.

## Salvamento local
- O progresso é salvo automaticamente no navegador usando `localStorage`.
- São preservados recursos, produção, preços e níveis das melhorias, Castelo, tropas, campanhas/reinos, missão ativa, progresso das missões, evento pendente e tela atual.
- O jogo salva após mudanças importantes, a cada 5 segundos e ao fechar/ocultar a página.
- O cronômetro dos Eventos do Trono também é retomado; se o prazo vencer enquanto o jogo estiver fechado, o evento fica disponível ao reabrir.
- Nesta versão não há produção de ouro/comida offline: fechar o jogo pausa a geração de recursos.

## Progressão real do Quartel
- O Quartel não pode ultrapassar o nível do Castelo.
- Evoluções exigem Castelo no nível-alvo e ouro suficiente.
- Custos: 3.000, 7.000, 12.500, 20.000, 30.000, 42.500, 57.500, 75.000 e 100.000 de ouro para os níveis 2–10.
- O botão gratuito de teste de nível do Quartel foi substituído pelo botão de evolução real.
- Espadachim desbloqueia no nível 1, Arqueiro no 2 e Cavaleiro no 3.
- Saves antigos com Quartel acima do Castelo são ajustados automaticamente ao nível máximo permitido.

- UI: botões de Missão e Eventos reposicionados como abas compactas no lado direito da tela, com baixa opacidade para preservar a visualização do cenário.

## Reset do progresso
- Botão `↻ Reset` nas ações rápidas laterais.
- Pede confirmação antes de apagar.
- Remove o save local do navegador e reinicia o jogo do zero.
